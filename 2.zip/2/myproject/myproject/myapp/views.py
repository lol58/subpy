import logging
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.http import HttpResponse
from django.contrib import messages  # Для отображения сообщений пользователю
from .models import TelegramUser
# Импортируйте ваши функции для взаимодействия с Telegram Bot API (будет добавлено в следующих ответах)
from .telegram_bot import get_telegram_auth_url, process_telegram_auth


logger = logging.getLogger(__name__)


def index(request):
    """
    Главная страница сайта.
    """
    if request.user.is_authenticated:
        telegram_user = getattr(request.user, 'telegram_user', None)
        context = {
            'username': request.user.username,
            'photo_url': telegram_user.photo_url if telegram_user else None,
        }
        return render(request, 'myapp/index.html', context)
    else:
        return render(request, 'myapp/index.html')


def telegram_login(request):
    """
    Обработка входа через Telegram.
    """
    auth_url = get_telegram_auth_url() # Функция из telegram_bot.py (будет добавлена позже)
    return redirect(auth_url)


def telegram_auth_callback(request):
    """
    Обработчик обратного вызова после авторизации в Telegram.
    """
    try:
        user = process_telegram_auth(request) # Функция из telegram_bot.py (будет добавлена позже)
        if user:
            login(request, user)
            messages.success(request, 'Успешная авторизация через Telegram!')
            return redirect('index') # Перенаправляем на главную страницу
        else:
            messages.error(request, 'Ошибка авторизации через Telegram.')
            return redirect('index')
    except Exception as e:
        logger.exception("Error during Telegram authentication:", exc_info=True)
        messages.error(request, 'Произошла ошибка. Попробуйте позже.')
        return redirect('index')


def logout_view(request):
    """
    Обработчик выхода из системы.
    """
    logout(request)
    messages.success(request, 'Вы успешно вышли из системы!')
    return redirect('index')