import requests
import logging
from django.conf import settings
from .models import TelegramUser
from telegram import Bot, Update, InlineKeyboardButton, InlineKeyboardMarkup, User
from telegram.ext import Updater, CallbackContext, CommandHandler, CallbackQueryHandler
from urllib.parse import urlencode, urljoin

logger = logging.getLogger(__name__)

BASE_URL = 'http://127.0.0.1:8000/'

def get_telegram_auth_url():
    """
    Генерирует URL для авторизации через Telegram.
    """
    #  Здесь вам нужно реализовать логику получения URL для авторизации
    #  с использованием Telegram Bot API.  Это может потребовать использования
    #  OAuth 2.0.  Этот пример  —  заглушка.  Вам нужно будет  заменить его
    #  на ваш собственный код, используя  Telegram Bot API и  возможно,  дополнительные  библиотеки.

    # Замените на вашу логику авторизации
    auth_url = urljoin(BASE_URL, 'telegram-auth-callback/')
    return auth_url

def process_telegram_auth(request):
    """
    Обрабатывает ответ от Telegram после авторизации.
    """
    #  Здесь вам нужно реализовать логику обработки ответа от Telegram,
    #  извлечения данных пользователя и создания/обновления  записи в базе данных.
    #  Этот пример — заглушка.

    # Замените на вашу логику обработки данных
    telegram_id = request.GET.get('id')
    first_name = request.GET.get('first_name')
    last_name = request.GET.get('last_name')
    username = request.GET.get('username')
    photo_url = request.GET.get('photo_url')

    if not all([telegram_id, first_name]):  # Проверка на обязательные поля
        return None

    try:
        user, created = TelegramUser.objects.get_or_create(telegram_id=telegram_id)
        user.first_name = first_name
        user.last_name = last_name
        user.username = username or ""
        user.photo_url = photo_url or ""
        user.save()

        # Связываем TelegramUser с пользователем Django
        django_user, created = User.objects.get_or_create(
            username=f'telegram_{telegram_id}')  # Создаем Django пользователя, если его нет
        user.user = django_user
        user.save()

        return django_user
    except Exception as e:
        logger.exception("Error processing Telegram auth:", exc_info=True)
        return None




# ---  Ниже  —  часть кода для запуска Telegram бота (будет развита в следующей части) ---

def start(update: Update, context: CallbackContext):
    keyboard = [[InlineKeyboardButton("Авторизоваться", callback_data='auth')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('Нажмите кнопку, чтобы авторизоваться:', reply_markup=reply_markup)


def button(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()
    if query.data == 'auth':
        query.edit_message_text(text="Вы нажали кнопку авторизоваться. Перенаправляю на сайт...")
        auth_url = get_telegram_auth_url()
        query.edit_message_text(text=f"Перейдите по ссылке: {auth_url}")


def run_telegram_bot():
    bot = Bot(token=settings.TELEGRAM_BOT_TOKEN)
    updater = Updater(bot=bot, use_context=True)
    dispatcher = updater.dispatcher
    dispatcher.add_handler(CommandHandler('start', start))
    dispatcher.add_handler(CallbackQueryHandler(button))
    updater.start_polling()
    updater.idle()

#Запустите бота в отдельном потоке (это нужно будет сделать в вашем production коде)

# if __name__ == "__main__":
#    run_telegram_bot()