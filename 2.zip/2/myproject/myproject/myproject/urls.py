from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.index, name='index'),
    path('telegram-login/', views.telegram_login, name='telegram-login'),
    path('telegram-auth-callback/', views.telegram_auth_callback, name='telegram-auth-callback'),
    path('logout/', views.logout_view, name='logout'),
]